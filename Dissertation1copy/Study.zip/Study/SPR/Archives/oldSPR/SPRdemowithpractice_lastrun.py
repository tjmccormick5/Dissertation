#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy2 Experiment Builder (v1.85.6),
    on Thu Mar  8 19:17:02 2018
If you publish work using this script please cite the PsychoPy publications:
    Peirce, JW (2007) PsychoPy - Psychophysics software in Python.
        Journal of Neuroscience Methods, 162(1-2), 8-13.
    Peirce, JW (2009) Generating stimuli for neuroscience using PsychoPy.
        Frontiers in Neuroinformatics, 2:10. doi: 10.3389/neuro.11.010.2008
"""

from __future__ import absolute_import, division
from psychopy import locale_setup, sound, gui, visual, core, data, event, logging
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER)
import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle
import os  # handy system and path functions
import sys  # to get file system encoding

# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__)).decode(sys.getfilesystemencoding())
os.chdir(_thisDir)

# Store info about the experiment session
expName = u'SPRdemowithpractice'  # from the Builder filename that created this script
expInfo = {'participant':'', 'session':'001'}
dlg = gui.DlgFromDict(dictionary=expInfo, title=expName)
if dlg.OK == False:
    core.quit()  # user pressed cancel
expInfo['date'] = data.getDateStr()  # add a simple timestamp
expInfo['expName'] = expName

# Data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
filename = _thisDir + os.sep + u'data/%s_%s_%s' % (expInfo['participant'], expName, expInfo['date'])

# An ExperimentHandler isn't essential but helps with data saving
thisExp = data.ExperimentHandler(name=expName, version='',
    extraInfo=expInfo, runtimeInfo=None,
    originPath=u'/Users/TimothyMcCormick/Desktop/SPR/Selfpaced reading/SPRdemowithpractice.psyexp',
    savePickle=True, saveWideText=True,
    dataFileName=filename)
# save a log file for detail verbose info
logFile = logging.LogFile(filename+'.log', level=logging.EXP)
logging.console.setLevel(logging.WARNING)  # this outputs to the screen, not a file

endExpNow = False  # flag for 'escape' or other condition => quit the exp

# Start Code - component code to be run before the window creation

# Setup the Window
win = visual.Window(
    size=(1440, 900), fullscr=True, screen=0,
    allowGUI=False, allowStencil=False,
    monitor='testMonitor', color=[0,0,0], colorSpace='rgb',
    blendMode='avg', useFBO=True)
# store frame rate of monitor if we can measure it
expInfo['frameRate'] = win.getActualFrameRate()
if expInfo['frameRate'] != None:
    frameDur = 1.0 / round(expInfo['frameRate'])
else:
    frameDur = 1.0 / 60.0  # could not measure, so guess

# Initialize components for Routine "intro"
introClock = core.Clock()
introText = visual.TextStim(win=win, name='introText',
    text='Instructions here\n\nPress space when ready.',
    font='Courier',
    pos=(0, 0), height=0.07, wrapWidth=None, ori=0, 
    color='black', colorSpace='rgb', opacity=1,
    depth=0.0);

# Initialize components for Routine "instrStroop"
instrStroopClock = core.Clock()
instrStroopText = visual.TextStim(win=win, name='instrStroopText',
    text='Explain the flanker task\n\n\nPress "space" when you\'re ready to proceed.',
    font='Courier',
    pos=(0, 0), height=0.07, wrapWidth=None, ori=0, 
    color='black', colorSpace='rgb', opacity=1,
    depth=0.0);

# Initialize components for Routine "stroop"
stroopClock = core.Clock()
stroopImages = visual.ImageStim(
    win=win, name='stroopImages',
    image='sin', mask=None,
    ori=0, pos=(0, 0), size=(1, 1),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=0.0)
fixation = visual.TextStim(win=win, name='fixation',
    text='+',
    font='Courier',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='black', colorSpace='rgb', opacity=1,
    depth=-2.0);

# Initialize components for Routine "postStroop"
postStroopClock = core.Clock()
postStrooptext = visual.TextStim(win=win, name='postStrooptext',
    text='Great! You got the hang of it!\n\nNow you\'re ready for the next component of the task.\n\nPress "space" when you\'re ready to continue.',
    font='Courier',
    pos=(0, 0), height=0.07, wrapWidth=None, ori=0, 
    color='black', colorSpace='rgb', opacity=1,
    depth=0.0);

# Initialize components for Routine "instrSPR"
instrSPRClock = core.Clock()
instrSPRtext = visual.TextStim(win=win, name='instrSPRtext',
    text='Explain sentences\n\nPress "space" when you\'re ready to proceed.',
    font='Courier',
    pos=(0, 0), height=0.07, wrapWidth=None, ori=0, 
    color='black', colorSpace='rgb', opacity=1,
    depth=0.0);

# Initialize components for Routine "instr1block1"
instr1block1Clock = core.Clock()
instrBlock1text = visual.TextStim(win=win, name='instrBlock1text',
    text='Great! It seems like you\'re getting the hang of it!\n\nAny questions? Feel free to raise your hand now, and a researcher will be happy to answer any questions!\n\nIf not, press "space" to continue.',
    font='Courier',
    pos=(0, 0), height=0.07, wrapWidth=None, ori=0, 
    color='black', colorSpace='rgb', opacity=1,
    depth=0.0);

# Initialize components for Routine "instr2block1"
instr2block1Clock = core.Clock()
instr2block1text = visual.TextStim(win=win, name='instr2block1text',
    text='Now, on this next section, we\'ll be combining the two previous tasks. \n\nJust like before, when you see arrows, you should choose \'f\' or \'j\', depending on the middle arrow.\n\nWhen you see a sentence, you will have to press "space" to advance the window and see the next word.\n\nFollowing each sentence, you\'ll have to answer a question, and pick \'f\' or \'j\' to choose the correct answer.\n    (\'f\' = left; \'j\' = right)',
    font='Courier',
    pos=(0, 0), height=0.07, wrapWidth=None, ori=0, 
    color='black', colorSpace='rgb', opacity=1,
    depth=0.0);

# Initialize components for Routine "stroop"
stroopClock = core.Clock()
stroopImages = visual.ImageStim(
    win=win, name='stroopImages',
    image='sin', mask=None,
    ori=0, pos=(0, 0), size=(1, 1),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=0.0)
fixation = visual.TextStim(win=win, name='fixation',
    text='+',
    font='Courier',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='black', colorSpace='rgb', opacity=1,
    depth=-2.0);

# Initialize components for Routine "trial"
trialClock = core.Clock()
block1_sentences = visual.TextStim(win=win, name='block1_sentences',
    text='default text',
    font=u'Courier',
    pos=(0, 0), height=0.07, wrapWidth=None, ori=0, 
    color=u'black', colorSpace='rgb', opacity=1,
    depth=0.0);


# Initialize components for Routine "CompQuestion"
CompQuestionClock = core.Clock()
block1_compQuestion = visual.TextStim(win=win, name='block1_compQuestion',
    text='default text',
    font='Courier',
    pos=(0, 0), height=0.07, wrapWidth=None, ori=0, 
    color='black', colorSpace='rgb', opacity=1,
    depth=0.0);
block1_compQuestionF = visual.TextStim(win=win, name='block1_compQuestionF',
    text='default text',
    font='Courier',
    pos=(-.25, -.5), height=0.07, wrapWidth=None, ori=0, 
    color='black', colorSpace='rgb', opacity=1,
    depth=-2.0);
compQuestion_J = visual.TextStim(win=win, name='compQuestion_J',
    text='default text',
    font='Courier',
    pos=(.25, -.5), height=0.07, wrapWidth=None, ori=0, 
    color='black', colorSpace='rgb', opacity=1,
    depth=-3.0);

# Initialize components for Routine "Break"
BreakClock = core.Clock()
Break1 = visual.TextStim(win=win, name='Break1',
    text='Need a minute? \n\nTake a drink, grab a snack, or just relax.\n\nPress "space" when you\'re ready to continue',
    font='Arial',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1,
    depth=0.0);

# Initialize components for Routine "stroop"
stroopClock = core.Clock()
stroopImages = visual.ImageStim(
    win=win, name='stroopImages',
    image='sin', mask=None,
    ori=0, pos=(0, 0), size=(1, 1),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=0.0)
fixation = visual.TextStim(win=win, name='fixation',
    text='+',
    font='Courier',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='black', colorSpace='rgb', opacity=1,
    depth=-2.0);

# Initialize components for Routine "trialBlock2"
trialBlock2Clock = core.Clock()
block2sentencetext = visual.TextStim(win=win, name='block2sentencetext',
    text='default text',
    font=u'courier',
    pos=(0, 0), height=0.07, wrapWidth=None, ori=0, 
    color=u'black', colorSpace='rgb', opacity=1,
    depth=0.0);


# Initialize components for Routine "compQuestionsBlock2"
compQuestionsBlock2Clock = core.Clock()
block2_compQuestion = visual.TextStim(win=win, name='block2_compQuestion',
    text='default text',
    font='courier',
    pos=(0, 0), height=0.07, wrapWidth=None, ori=0, 
    color='black', colorSpace='rgb', opacity=1,
    depth=0.0);
block2compquestionF = visual.TextStim(win=win, name='block2compquestionF',
    text='default text',
    font='Courier',
    pos=(-.25, -.5), height=0.07, wrapWidth=None, ori=0, 
    color='black', colorSpace='rgb', opacity=1,
    depth=-2.0);
block2compquestionJ = visual.TextStim(win=win, name='block2compquestionJ',
    text='default text',
    font='Courier',
    pos=(.25, -.5), height=0.07, wrapWidth=None, ori=0, 
    color='black', colorSpace='rgb', opacity=1,
    depth=-3.0);

# Initialize components for Routine "Thanks"
ThanksClock = core.Clock()
text_3 = visual.TextStim(win=win, name='text_3',
    text='Thanks for participating!',
    font='Courier',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='black', colorSpace='rgb', opacity=1,
    depth=0.0);

# Create some handy timers
globalClock = core.Clock()  # to track the time since experiment started
routineTimer = core.CountdownTimer()  # to track time remaining of each (non-slip) routine 

# ------Prepare to start Routine "intro"-------
t = 0
introClock.reset()  # clock
frameN = -1
continueRoutine = True
# update component parameters for each repeat
introResponse = event.BuilderKeyResponse()
# keep track of which components have finished
introComponents = [introText, introResponse]
for thisComponent in introComponents:
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

# -------Start Routine "intro"-------
while continueRoutine:
    # get current time
    t = introClock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *introText* updates
    if t >= 0.0 and introText.status == NOT_STARTED:
        # keep track of start time/frame for later
        introText.tStart = t
        introText.frameNStart = frameN  # exact frame index
        introText.setAutoDraw(True)
    
    # *introResponse* updates
    if t >= 0.0 and introResponse.status == NOT_STARTED:
        # keep track of start time/frame for later
        introResponse.tStart = t
        introResponse.frameNStart = frameN  # exact frame index
        introResponse.status = STARTED
        # keyboard checking is just starting
        win.callOnFlip(introResponse.clock.reset)  # t=0 on next screen flip
        event.clearEvents(eventType='keyboard')
    if introResponse.status == STARTED:
        theseKeys = event.getKeys(keyList=['space'])
        
        # check for quit:
        if "escape" in theseKeys:
            endExpNow = True
        if len(theseKeys) > 0:  # at least one key was pressed
            introResponse.keys = theseKeys[-1]  # just the last key pressed
            introResponse.rt = introResponse.clock.getTime()
            # a response ends the routine
            continueRoutine = False
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in introComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # check for quit (the Esc key)
    if endExpNow or event.getKeys(keyList=["escape"]):
        core.quit()
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "intro"-------
for thisComponent in introComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# check responses
if introResponse.keys in ['', [], None]:  # No response was made
    introResponse.keys=None
thisExp.addData('introResponse.keys',introResponse.keys)
if introResponse.keys != None:  # we had a response
    thisExp.addData('introResponse.rt', introResponse.rt)
thisExp.nextEntry()
# the Routine "intro" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "instrStroop"-------
t = 0
instrStroopClock.reset()  # clock
frameN = -1
continueRoutine = True
# update component parameters for each repeat
instrStroopResponse = event.BuilderKeyResponse()
# keep track of which components have finished
instrStroopComponents = [instrStroopText, instrStroopResponse]
for thisComponent in instrStroopComponents:
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

# -------Start Routine "instrStroop"-------
while continueRoutine:
    # get current time
    t = instrStroopClock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *instrStroopText* updates
    if t >= 0.0 and instrStroopText.status == NOT_STARTED:
        # keep track of start time/frame for later
        instrStroopText.tStart = t
        instrStroopText.frameNStart = frameN  # exact frame index
        instrStroopText.setAutoDraw(True)
    
    # *instrStroopResponse* updates
    if t >= 0.0 and instrStroopResponse.status == NOT_STARTED:
        # keep track of start time/frame for later
        instrStroopResponse.tStart = t
        instrStroopResponse.frameNStart = frameN  # exact frame index
        instrStroopResponse.status = STARTED
        # keyboard checking is just starting
        win.callOnFlip(instrStroopResponse.clock.reset)  # t=0 on next screen flip
        event.clearEvents(eventType='keyboard')
    if instrStroopResponse.status == STARTED:
        theseKeys = event.getKeys(keyList=['space'])
        
        # check for quit:
        if "escape" in theseKeys:
            endExpNow = True
        if len(theseKeys) > 0:  # at least one key was pressed
            instrStroopResponse.keys = theseKeys[-1]  # just the last key pressed
            instrStroopResponse.rt = instrStroopResponse.clock.getTime()
            # a response ends the routine
            continueRoutine = False
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in instrStroopComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # check for quit (the Esc key)
    if endExpNow or event.getKeys(keyList=["escape"]):
        core.quit()
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "instrStroop"-------
for thisComponent in instrStroopComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# check responses
if instrStroopResponse.keys in ['', [], None]:  # No response was made
    instrStroopResponse.keys=None
thisExp.addData('instrStroopResponse.keys',instrStroopResponse.keys)
if instrStroopResponse.keys != None:  # we had a response
    thisExp.addData('instrStroopResponse.rt', instrStroopResponse.rt)
thisExp.nextEntry()
# the Routine "instrStroop" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
practiceStroop = data.TrialHandler(nReps=2, method='random', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions(u'stimsinonecell.xlsx'),
    seed=None, name='practiceStroop')
thisExp.addLoop(practiceStroop)  # add the loop to the experiment
thisPracticeStroop = practiceStroop.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisPracticeStroop.rgb)
if thisPracticeStroop != None:
    for paramName in thisPracticeStroop.keys():
        exec(paramName + '= thisPracticeStroop.' + paramName)

for thisPracticeStroop in practiceStroop:
    currentLoop = practiceStroop
    # abbreviate parameter names if possible (e.g. rgb = thisPracticeStroop.rgb)
    if thisPracticeStroop != None:
        for paramName in thisPracticeStroop.keys():
            exec(paramName + '= thisPracticeStroop.' + paramName)
    
    # ------Prepare to start Routine "stroop"-------
    t = 0
    stroopClock.reset()  # clock
    frameN = -1
    continueRoutine = True
    # update component parameters for each repeat
    stroopImages.setImage(image)
    stroopResponse = event.BuilderKeyResponse()
    # keep track of which components have finished
    stroopComponents = [stroopImages, stroopResponse, fixation]
    for thisComponent in stroopComponents:
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    # -------Start Routine "stroop"-------
    while continueRoutine:
        # get current time
        t = stroopClock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *stroopImages* updates
        if t >= 1.5 and stroopImages.status == NOT_STARTED:
            # keep track of start time/frame for later
            stroopImages.tStart = t
            stroopImages.frameNStart = frameN  # exact frame index
            stroopImages.setAutoDraw(True)
        
        # *stroopResponse* updates
        if t >= 1.5 and stroopResponse.status == NOT_STARTED:
            # keep track of start time/frame for later
            stroopResponse.tStart = t
            stroopResponse.frameNStart = frameN  # exact frame index
            stroopResponse.status = STARTED
            # keyboard checking is just starting
            win.callOnFlip(stroopResponse.clock.reset)  # t=0 on next screen flip
            event.clearEvents(eventType='keyboard')
        if stroopResponse.status == STARTED:
            theseKeys = event.getKeys(keyList=['f', 'j'])
            
            # check for quit:
            if "escape" in theseKeys:
                endExpNow = True
            if len(theseKeys) > 0:  # at least one key was pressed
                stroopResponse.keys = theseKeys[-1]  # just the last key pressed
                stroopResponse.rt = stroopResponse.clock.getTime()
                # was this 'correct'?
                if (stroopResponse.keys == str(corrAns)) or (stroopResponse.keys == corrAns):
                    stroopResponse.corr = 1
                else:
                    stroopResponse.corr = 0
                # a response ends the routine
                continueRoutine = False
        
        # *fixation* updates
        if t >= 0.5 and fixation.status == NOT_STARTED:
            # keep track of start time/frame for later
            fixation.tStart = t
            fixation.frameNStart = frameN  # exact frame index
            fixation.setAutoDraw(True)
        frameRemains = 0.5 + .5- win.monitorFramePeriod * 0.75  # most of one frame period left
        if fixation.status == STARTED and t >= frameRemains:
            fixation.setAutoDraw(False)
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in stroopComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # check for quit (the Esc key)
        if endExpNow or event.getKeys(keyList=["escape"]):
            core.quit()
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "stroop"-------
    for thisComponent in stroopComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # check responses
    if stroopResponse.keys in ['', [], None]:  # No response was made
        stroopResponse.keys=None
        # was no response the correct answer?!
        if str(corrAns).lower() == 'none':
           stroopResponse.corr = 1  # correct non-response
        else:
           stroopResponse.corr = 0  # failed to respond (incorrectly)
    # store data for practiceStroop (TrialHandler)
    practiceStroop.addData('stroopResponse.keys',stroopResponse.keys)
    practiceStroop.addData('stroopResponse.corr', stroopResponse.corr)
    if stroopResponse.keys != None:  # we had a response
        practiceStroop.addData('stroopResponse.rt', stroopResponse.rt)
    # the Routine "stroop" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    thisExp.nextEntry()
    
# completed 2 repeats of 'practiceStroop'


# ------Prepare to start Routine "postStroop"-------
t = 0
postStroopClock.reset()  # clock
frameN = -1
continueRoutine = True
# update component parameters for each repeat
postStroopResponse = event.BuilderKeyResponse()
# keep track of which components have finished
postStroopComponents = [postStrooptext, postStroopResponse]
for thisComponent in postStroopComponents:
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

# -------Start Routine "postStroop"-------
while continueRoutine:
    # get current time
    t = postStroopClock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *postStrooptext* updates
    if t >= 0.0 and postStrooptext.status == NOT_STARTED:
        # keep track of start time/frame for later
        postStrooptext.tStart = t
        postStrooptext.frameNStart = frameN  # exact frame index
        postStrooptext.setAutoDraw(True)
    
    # *postStroopResponse* updates
    if t >= 0.0 and postStroopResponse.status == NOT_STARTED:
        # keep track of start time/frame for later
        postStroopResponse.tStart = t
        postStroopResponse.frameNStart = frameN  # exact frame index
        postStroopResponse.status = STARTED
        # keyboard checking is just starting
        win.callOnFlip(postStroopResponse.clock.reset)  # t=0 on next screen flip
        event.clearEvents(eventType='keyboard')
    if postStroopResponse.status == STARTED:
        theseKeys = event.getKeys(keyList=['space'])
        
        # check for quit:
        if "escape" in theseKeys:
            endExpNow = True
        if len(theseKeys) > 0:  # at least one key was pressed
            postStroopResponse.keys = theseKeys[-1]  # just the last key pressed
            postStroopResponse.rt = postStroopResponse.clock.getTime()
            # a response ends the routine
            continueRoutine = False
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in postStroopComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # check for quit (the Esc key)
    if endExpNow or event.getKeys(keyList=["escape"]):
        core.quit()
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "postStroop"-------
for thisComponent in postStroopComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# check responses
if postStroopResponse.keys in ['', [], None]:  # No response was made
    postStroopResponse.keys=None
thisExp.addData('postStroopResponse.keys',postStroopResponse.keys)
if postStroopResponse.keys != None:  # we had a response
    thisExp.addData('postStroopResponse.rt', postStroopResponse.rt)
thisExp.nextEntry()
# the Routine "postStroop" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "instrSPR"-------
t = 0
instrSPRClock.reset()  # clock
frameN = -1
continueRoutine = True
# update component parameters for each repeat
instrSPRresponse = event.BuilderKeyResponse()
# keep track of which components have finished
instrSPRComponents = [instrSPRtext, instrSPRresponse]
for thisComponent in instrSPRComponents:
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

# -------Start Routine "instrSPR"-------
while continueRoutine:
    # get current time
    t = instrSPRClock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *instrSPRtext* updates
    if t >= 0.0 and instrSPRtext.status == NOT_STARTED:
        # keep track of start time/frame for later
        instrSPRtext.tStart = t
        instrSPRtext.frameNStart = frameN  # exact frame index
        instrSPRtext.setAutoDraw(True)
    
    # *instrSPRresponse* updates
    if t >= 0.0 and instrSPRresponse.status == NOT_STARTED:
        # keep track of start time/frame for later
        instrSPRresponse.tStart = t
        instrSPRresponse.frameNStart = frameN  # exact frame index
        instrSPRresponse.status = STARTED
        # keyboard checking is just starting
        win.callOnFlip(instrSPRresponse.clock.reset)  # t=0 on next screen flip
        event.clearEvents(eventType='keyboard')
    if instrSPRresponse.status == STARTED:
        theseKeys = event.getKeys(keyList=['space'])
        
        # check for quit:
        if "escape" in theseKeys:
            endExpNow = True
        if len(theseKeys) > 0:  # at least one key was pressed
            instrSPRresponse.keys = theseKeys[-1]  # just the last key pressed
            instrSPRresponse.rt = instrSPRresponse.clock.getTime()
            # a response ends the routine
            continueRoutine = False
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in instrSPRComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # check for quit (the Esc key)
    if endExpNow or event.getKeys(keyList=["escape"]):
        core.quit()
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "instrSPR"-------
for thisComponent in instrSPRComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# check responses
if instrSPRresponse.keys in ['', [], None]:  # No response was made
    instrSPRresponse.keys=None
thisExp.addData('instrSPRresponse.keys',instrSPRresponse.keys)
if instrSPRresponse.keys != None:  # we had a response
    thisExp.addData('instrSPRresponse.rt', instrSPRresponse.rt)
thisExp.nextEntry()
# the Routine "instrSPR" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "instr1block1"-------
t = 0
instr1block1Clock.reset()  # clock
frameN = -1
continueRoutine = True
# update component parameters for each repeat
instrBlock1keypress = event.BuilderKeyResponse()
# keep track of which components have finished
instr1block1Components = [instrBlock1text, instrBlock1keypress]
for thisComponent in instr1block1Components:
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

# -------Start Routine "instr1block1"-------
while continueRoutine:
    # get current time
    t = instr1block1Clock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *instrBlock1text* updates
    if t >= 0.0 and instrBlock1text.status == NOT_STARTED:
        # keep track of start time/frame for later
        instrBlock1text.tStart = t
        instrBlock1text.frameNStart = frameN  # exact frame index
        instrBlock1text.setAutoDraw(True)
    
    # *instrBlock1keypress* updates
    if t >= 0.0 and instrBlock1keypress.status == NOT_STARTED:
        # keep track of start time/frame for later
        instrBlock1keypress.tStart = t
        instrBlock1keypress.frameNStart = frameN  # exact frame index
        instrBlock1keypress.status = STARTED
        # keyboard checking is just starting
        win.callOnFlip(instrBlock1keypress.clock.reset)  # t=0 on next screen flip
        event.clearEvents(eventType='keyboard')
    if instrBlock1keypress.status == STARTED:
        theseKeys = event.getKeys(keyList=['space'])
        
        # check for quit:
        if "escape" in theseKeys:
            endExpNow = True
        if len(theseKeys) > 0:  # at least one key was pressed
            instrBlock1keypress.keys = theseKeys[-1]  # just the last key pressed
            instrBlock1keypress.rt = instrBlock1keypress.clock.getTime()
            # a response ends the routine
            continueRoutine = False
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in instr1block1Components:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # check for quit (the Esc key)
    if endExpNow or event.getKeys(keyList=["escape"]):
        core.quit()
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "instr1block1"-------
for thisComponent in instr1block1Components:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# check responses
if instrBlock1keypress.keys in ['', [], None]:  # No response was made
    instrBlock1keypress.keys=None
thisExp.addData('instrBlock1keypress.keys',instrBlock1keypress.keys)
if instrBlock1keypress.keys != None:  # we had a response
    thisExp.addData('instrBlock1keypress.rt', instrBlock1keypress.rt)
thisExp.nextEntry()
# the Routine "instr1block1" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "instr2block1"-------
t = 0
instr2block1Clock.reset()  # clock
frameN = -1
continueRoutine = True
# update component parameters for each repeat
# keep track of which components have finished
instr2block1Components = [instr2block1text]
for thisComponent in instr2block1Components:
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

# -------Start Routine "instr2block1"-------
while continueRoutine:
    # get current time
    t = instr2block1Clock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *instr2block1text* updates
    if t >= 0.0 and instr2block1text.status == NOT_STARTED:
        # keep track of start time/frame for later
        instr2block1text.tStart = t
        instr2block1text.frameNStart = frameN  # exact frame index
        instr2block1text.setAutoDraw(True)
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in instr2block1Components:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # check for quit (the Esc key)
    if endExpNow or event.getKeys(keyList=["escape"]):
        core.quit()
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "instr2block1"-------
for thisComponent in instr2block1Components:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "instr2block1" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
block1 = data.TrialHandler(nReps=1, method='random', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions(u'stimsinonecell.xlsx'),
    seed=None, name='block1')
thisExp.addLoop(block1)  # add the loop to the experiment
thisBlock1 = block1.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisBlock1.rgb)
if thisBlock1 != None:
    for paramName in thisBlock1.keys():
        exec(paramName + '= thisBlock1.' + paramName)

for thisBlock1 in block1:
    currentLoop = block1
    # abbreviate parameter names if possible (e.g. rgb = thisBlock1.rgb)
    if thisBlock1 != None:
        for paramName in thisBlock1.keys():
            exec(paramName + '= thisBlock1.' + paramName)
    
    # ------Prepare to start Routine "stroop"-------
    t = 0
    stroopClock.reset()  # clock
    frameN = -1
    continueRoutine = True
    # update component parameters for each repeat
    stroopImages.setImage(image)
    stroopResponse = event.BuilderKeyResponse()
    # keep track of which components have finished
    stroopComponents = [stroopImages, stroopResponse, fixation]
    for thisComponent in stroopComponents:
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    # -------Start Routine "stroop"-------
    while continueRoutine:
        # get current time
        t = stroopClock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *stroopImages* updates
        if t >= 1.5 and stroopImages.status == NOT_STARTED:
            # keep track of start time/frame for later
            stroopImages.tStart = t
            stroopImages.frameNStart = frameN  # exact frame index
            stroopImages.setAutoDraw(True)
        
        # *stroopResponse* updates
        if t >= 1.5 and stroopResponse.status == NOT_STARTED:
            # keep track of start time/frame for later
            stroopResponse.tStart = t
            stroopResponse.frameNStart = frameN  # exact frame index
            stroopResponse.status = STARTED
            # keyboard checking is just starting
            win.callOnFlip(stroopResponse.clock.reset)  # t=0 on next screen flip
            event.clearEvents(eventType='keyboard')
        if stroopResponse.status == STARTED:
            theseKeys = event.getKeys(keyList=['f', 'j'])
            
            # check for quit:
            if "escape" in theseKeys:
                endExpNow = True
            if len(theseKeys) > 0:  # at least one key was pressed
                stroopResponse.keys = theseKeys[-1]  # just the last key pressed
                stroopResponse.rt = stroopResponse.clock.getTime()
                # was this 'correct'?
                if (stroopResponse.keys == str(corrAns)) or (stroopResponse.keys == corrAns):
                    stroopResponse.corr = 1
                else:
                    stroopResponse.corr = 0
                # a response ends the routine
                continueRoutine = False
        
        # *fixation* updates
        if t >= 0.5 and fixation.status == NOT_STARTED:
            # keep track of start time/frame for later
            fixation.tStart = t
            fixation.frameNStart = frameN  # exact frame index
            fixation.setAutoDraw(True)
        frameRemains = 0.5 + .5- win.monitorFramePeriod * 0.75  # most of one frame period left
        if fixation.status == STARTED and t >= frameRemains:
            fixation.setAutoDraw(False)
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in stroopComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # check for quit (the Esc key)
        if endExpNow or event.getKeys(keyList=["escape"]):
            core.quit()
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "stroop"-------
    for thisComponent in stroopComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # check responses
    if stroopResponse.keys in ['', [], None]:  # No response was made
        stroopResponse.keys=None
        # was no response the correct answer?!
        if str(corrAns).lower() == 'none':
           stroopResponse.corr = 1  # correct non-response
        else:
           stroopResponse.corr = 0  # failed to respond (incorrectly)
    # store data for block1 (TrialHandler)
    block1.addData('stroopResponse.keys',stroopResponse.keys)
    block1.addData('stroopResponse.corr', stroopResponse.corr)
    if stroopResponse.keys != None:  # we had a response
        block1.addData('stroopResponse.rt', stroopResponse.rt)
    # the Routine "stroop" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "trial"-------
    t = 0
    trialClock.reset()  # clock
    frameN = -1
    continueRoutine = True
    # update component parameters for each repeat
    block1_sentences.setText(block1sentences)
    keyresponse = event.BuilderKeyResponse()
    # remove any keypresses remaining in the buffer from 
    # before  this routine started:
    event.clearEvents() 
    sentenceList = block1sentences.split() 
    # this breaks your sentence's single string of characters into a list of individual 
    # words, e.g. 'The quick brown fox.' becomes ['The', 'quick', 'brown', 'fox.'] 
    
    # keep track of which word we are up to: 
    wordNumber = -1 # -1 as we haven't started yet 
    
    # now define a function which we can use here and later on to replace letters with '-': 
    
    def replaceWithdash(textList, currentWordNumber): 
        
        dashSentence = '' 
        for index, word in enumerate(textList): # cycle through the words and their index numbers 
            if index != currentWordNumber: 
                dashSentence = dashSentence + ' ' + '-' * len(word)# add a string of dash characters 
            else:
                dashSentence = dashSentence + ' ' + word #for current word, but space was appearing between period and final word, so put space before each word rather than after
        return dashSentence +'.' # yields the manipulated sentence 
    
    # now at the very beginning of the trial, we need to run this function for the 
    # first time. As the current word number is -1, it should make all words '-'. 
    # Use the actual name of your Builder text component here: 
    
    block1_sentences.text = replaceWithdash(sentenceList, wordNumber) 
    
    # In the Builder interface, specify a "constant" value for the text content, e.g. 
    # 'test', so it doesn't conflict with our code. 
    
    # keep track of which components have finished
    trialComponents = [block1_sentences, keyresponse]
    for thisComponent in trialComponents:
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    # -------Start Routine "trial"-------
    while continueRoutine:
        # get current time
        t = trialClock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *block1_sentences* updates
        if t >= 0 and block1_sentences.status == NOT_STARTED:
            # keep track of start time/frame for later
            block1_sentences.tStart = t
            block1_sentences.frameNStart = frameN  # exact frame index
            block1_sentences.setAutoDraw(True)
        
        # *keyresponse* updates
        if t >= 0 and keyresponse.status == NOT_STARTED:
            # keep track of start time/frame for later
            keyresponse.tStart = t
            keyresponse.frameNStart = frameN  # exact frame index
            keyresponse.status = STARTED
            # keyboard checking is just starting
            win.callOnFlip(keyresponse.clock.reset)  # t=0 on next screen flip
            event.clearEvents(eventType='keyboard')
        if keyresponse.status == STARTED:
            theseKeys = event.getKeys(keyList=['y', 'n', 'left', 'right', 'space'])
            
            # check for quit:
            if "escape" in theseKeys:
                endExpNow = True
            if len(theseKeys) > 0:  # at least one key was pressed
                keyresponse.keys = theseKeys[-1]  # just the last key pressed
                keyresponse.rt = keyresponse.clock.getTime()
        keypresses = event.waitKeys() # returns a list of keypresses 
        
        if len(keypresses) > 0: # at least one key was pushed 
        
            if 'space' in keypresses: 
                
                thisResponseTime = t # the current time in the trial 
                wordNumber = wordNumber + 1 
                if wordNumber < len(sentenceList): 
        
                    if wordNumber == 0: # need to initialise a variable: 
                        timeOfLastResponse = 0 
        
                    # save the inter response interval for this keypress, 
                    # in variables called IRI_0, IRI_1, etc: 
                    thisExp.addData('Region_' + str(wordNumber), thisResponseTime - timeOfLastResponse) 
                    timeOfLastResponse = thisResponseTime 
        
                    # update the text by masking all but the current word 
                    block1_sentences.text = replaceWithdash(sentenceList, wordNumber) 
                else: 
                    continueRoutine = False # time to go on to the next trial 
        
            elif 'escape' in keypresses: 
        
                core.quit() # I think you'll need to handle quitting manually now. 
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in trialComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # check for quit (the Esc key)
        if endExpNow or event.getKeys(keyList=["escape"]):
            core.quit()
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "trial"-------
    for thisComponent in trialComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # check responses
    if keyresponse.keys in ['', [], None]:  # No response was made
        keyresponse.keys=None
    block1.addData('keyresponse.keys',keyresponse.keys)
    if keyresponse.keys != None:  # we had a response
        block1.addData('keyresponse.rt', keyresponse.rt)
    
    # the Routine "trial" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "CompQuestion"-------
    t = 0
    CompQuestionClock.reset()  # clock
    frameN = -1
    continueRoutine = True
    # update component parameters for each repeat
    block1_compQuestion.setText(block1compQuestion)
    compQuetions_Response = event.BuilderKeyResponse()
    block1_compQuestionF.setText(block1compQuestionF)
    compQuestion_J.setText(compQuestionJ)
    # keep track of which components have finished
    CompQuestionComponents = [block1_compQuestion, compQuetions_Response, block1_compQuestionF, compQuestion_J]
    for thisComponent in CompQuestionComponents:
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    # -------Start Routine "CompQuestion"-------
    while continueRoutine:
        # get current time
        t = CompQuestionClock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *block1_compQuestion* updates
        if t >= 0.0 and block1_compQuestion.status == NOT_STARTED:
            # keep track of start time/frame for later
            block1_compQuestion.tStart = t
            block1_compQuestion.frameNStart = frameN  # exact frame index
            block1_compQuestion.setAutoDraw(True)
        
        # *compQuetions_Response* updates
        if t >= 0.0 and compQuetions_Response.status == NOT_STARTED:
            # keep track of start time/frame for later
            compQuetions_Response.tStart = t
            compQuetions_Response.frameNStart = frameN  # exact frame index
            compQuetions_Response.status = STARTED
            # keyboard checking is just starting
            compQuetions_Response.clock.reset()  # now t=0
            event.clearEvents(eventType='keyboard')
        if compQuetions_Response.status == STARTED:
            theseKeys = event.getKeys(keyList=['f', 'j'])
            
            # check for quit:
            if "escape" in theseKeys:
                endExpNow = True
            if len(theseKeys) > 0:  # at least one key was pressed
                compQuetions_Response.keys = theseKeys[-1]  # just the last key pressed
                compQuetions_Response.rt = compQuetions_Response.clock.getTime()
                # was this 'correct'?
                if (compQuetions_Response.keys == str(compQuestionResponse)) or (compQuetions_Response.keys == compQuestionResponse):
                    compQuetions_Response.corr = 1
                else:
                    compQuetions_Response.corr = 0
                # a response ends the routine
                continueRoutine = False
        
        # *block1_compQuestionF* updates
        if t >= 0.0 and block1_compQuestionF.status == NOT_STARTED:
            # keep track of start time/frame for later
            block1_compQuestionF.tStart = t
            block1_compQuestionF.frameNStart = frameN  # exact frame index
            block1_compQuestionF.setAutoDraw(True)
        
        # *compQuestion_J* updates
        if t >= 0.0 and compQuestion_J.status == NOT_STARTED:
            # keep track of start time/frame for later
            compQuestion_J.tStart = t
            compQuestion_J.frameNStart = frameN  # exact frame index
            compQuestion_J.setAutoDraw(True)
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in CompQuestionComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # check for quit (the Esc key)
        if endExpNow or event.getKeys(keyList=["escape"]):
            core.quit()
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "CompQuestion"-------
    for thisComponent in CompQuestionComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # check responses
    if compQuetions_Response.keys in ['', [], None]:  # No response was made
        compQuetions_Response.keys=None
        # was no response the correct answer?!
        if str(compQuestionResponse).lower() == 'none':
           compQuetions_Response.corr = 1  # correct non-response
        else:
           compQuetions_Response.corr = 0  # failed to respond (incorrectly)
    # store data for block1 (TrialHandler)
    block1.addData('compQuetions_Response.keys',compQuetions_Response.keys)
    block1.addData('compQuetions_Response.corr', compQuetions_Response.corr)
    if compQuetions_Response.keys != None:  # we had a response
        block1.addData('compQuetions_Response.rt', compQuetions_Response.rt)
    # the Routine "CompQuestion" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    thisExp.nextEntry()
    
# completed 1 repeats of 'block1'


# ------Prepare to start Routine "Break"-------
t = 0
BreakClock.reset()  # clock
frameN = -1
continueRoutine = True
routineTimer.add(1.000000)
# update component parameters for each repeat
# keep track of which components have finished
BreakComponents = [Break1]
for thisComponent in BreakComponents:
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

# -------Start Routine "Break"-------
while continueRoutine and routineTimer.getTime() > 0:
    # get current time
    t = BreakClock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *Break1* updates
    if t >= 0.0 and Break1.status == NOT_STARTED:
        # keep track of start time/frame for later
        Break1.tStart = t
        Break1.frameNStart = frameN  # exact frame index
        Break1.setAutoDraw(True)
    frameRemains = 0.0 + 1.0- win.monitorFramePeriod * 0.75  # most of one frame period left
    if Break1.status == STARTED and t >= frameRemains:
        Break1.setAutoDraw(False)
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in BreakComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # check for quit (the Esc key)
    if endExpNow or event.getKeys(keyList=["escape"]):
        core.quit()
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Break"-------
for thisComponent in BreakComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)

# set up handler to look after randomisation of conditions etc
Block2 = data.TrialHandler(nReps=1, method='random', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions(u'stimsinonecell.xlsx'),
    seed=None, name='Block2')
thisExp.addLoop(Block2)  # add the loop to the experiment
thisBlock2 = Block2.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisBlock2.rgb)
if thisBlock2 != None:
    for paramName in thisBlock2.keys():
        exec(paramName + '= thisBlock2.' + paramName)

for thisBlock2 in Block2:
    currentLoop = Block2
    # abbreviate parameter names if possible (e.g. rgb = thisBlock2.rgb)
    if thisBlock2 != None:
        for paramName in thisBlock2.keys():
            exec(paramName + '= thisBlock2.' + paramName)
    
    # ------Prepare to start Routine "stroop"-------
    t = 0
    stroopClock.reset()  # clock
    frameN = -1
    continueRoutine = True
    # update component parameters for each repeat
    stroopImages.setImage(image)
    stroopResponse = event.BuilderKeyResponse()
    # keep track of which components have finished
    stroopComponents = [stroopImages, stroopResponse, fixation]
    for thisComponent in stroopComponents:
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    # -------Start Routine "stroop"-------
    while continueRoutine:
        # get current time
        t = stroopClock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *stroopImages* updates
        if t >= 1.5 and stroopImages.status == NOT_STARTED:
            # keep track of start time/frame for later
            stroopImages.tStart = t
            stroopImages.frameNStart = frameN  # exact frame index
            stroopImages.setAutoDraw(True)
        
        # *stroopResponse* updates
        if t >= 1.5 and stroopResponse.status == NOT_STARTED:
            # keep track of start time/frame for later
            stroopResponse.tStart = t
            stroopResponse.frameNStart = frameN  # exact frame index
            stroopResponse.status = STARTED
            # keyboard checking is just starting
            win.callOnFlip(stroopResponse.clock.reset)  # t=0 on next screen flip
            event.clearEvents(eventType='keyboard')
        if stroopResponse.status == STARTED:
            theseKeys = event.getKeys(keyList=['f', 'j'])
            
            # check for quit:
            if "escape" in theseKeys:
                endExpNow = True
            if len(theseKeys) > 0:  # at least one key was pressed
                stroopResponse.keys = theseKeys[-1]  # just the last key pressed
                stroopResponse.rt = stroopResponse.clock.getTime()
                # was this 'correct'?
                if (stroopResponse.keys == str(corrAns)) or (stroopResponse.keys == corrAns):
                    stroopResponse.corr = 1
                else:
                    stroopResponse.corr = 0
                # a response ends the routine
                continueRoutine = False
        
        # *fixation* updates
        if t >= 0.5 and fixation.status == NOT_STARTED:
            # keep track of start time/frame for later
            fixation.tStart = t
            fixation.frameNStart = frameN  # exact frame index
            fixation.setAutoDraw(True)
        frameRemains = 0.5 + .5- win.monitorFramePeriod * 0.75  # most of one frame period left
        if fixation.status == STARTED and t >= frameRemains:
            fixation.setAutoDraw(False)
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in stroopComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # check for quit (the Esc key)
        if endExpNow or event.getKeys(keyList=["escape"]):
            core.quit()
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "stroop"-------
    for thisComponent in stroopComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # check responses
    if stroopResponse.keys in ['', [], None]:  # No response was made
        stroopResponse.keys=None
        # was no response the correct answer?!
        if str(corrAns).lower() == 'none':
           stroopResponse.corr = 1  # correct non-response
        else:
           stroopResponse.corr = 0  # failed to respond (incorrectly)
    # store data for Block2 (TrialHandler)
    Block2.addData('stroopResponse.keys',stroopResponse.keys)
    Block2.addData('stroopResponse.corr', stroopResponse.corr)
    if stroopResponse.keys != None:  # we had a response
        Block2.addData('stroopResponse.rt', stroopResponse.rt)
    # the Routine "stroop" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "trialBlock2"-------
    t = 0
    trialBlock2Clock.reset()  # clock
    frameN = -1
    continueRoutine = True
    # update component parameters for each repeat
    block2sentencetext.setText(block2sentences)
    block2response = event.BuilderKeyResponse()
    # remove any keypresses remaining in the buffer from 
    # before  this routine started:
    event.clearEvents() 
    sentenceList = block2sentences.split() 
    # this breaks your sentence's single string of characters into a list of individual 
    # words, e.g. 'The quick brown fox.' becomes ['The', 'quick', 'brown', 'fox.'] 
    
    # keep track of which word we are up to: 
    wordNumber = -1 # -1 as we haven't started yet 
    
    # now define a function which we can use here and later on to replace letters with '-': 
    
    def replaceWithdash(textList, currentWordNumber): 
        
        dashSentence = '' 
        for index, word in enumerate(textList): # cycle through the words and their index numbers 
            if index != currentWordNumber: 
                dashSentence = dashSentence + ' ' + '-' * len(word)# add a string of dash characters 
            else:
                dashSentence = dashSentence + ' ' + word #for current word, but space was appearing between period and final word, so put space before each word rather than after
        return dashSentence +'.' # yields the manipulated sentence 
    
    # now at the very beginning of the trial, we need to run this function for the 
    # first time. As the current word number is -1, it should make all words '-'. 
    # Use the actual name of your Builder text component here: 
    
    block2sentencetext.text = replaceWithdash(sentenceList, wordNumber) 
    
    # In the Builder interface, specify a "constant" value for the text content, e.g. 
    # 'test', so it doesn't conflict with our code. 
    
    # keep track of which components have finished
    trialBlock2Components = [block2sentencetext, block2response]
    for thisComponent in trialBlock2Components:
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    # -------Start Routine "trialBlock2"-------
    while continueRoutine:
        # get current time
        t = trialBlock2Clock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *block2sentencetext* updates
        if t >= 0.0 and block2sentencetext.status == NOT_STARTED:
            # keep track of start time/frame for later
            block2sentencetext.tStart = t
            block2sentencetext.frameNStart = frameN  # exact frame index
            block2sentencetext.setAutoDraw(True)
        
        # *block2response* updates
        if t >= 0.0 and block2response.status == NOT_STARTED:
            # keep track of start time/frame for later
            block2response.tStart = t
            block2response.frameNStart = frameN  # exact frame index
            block2response.status = STARTED
            # keyboard checking is just starting
            win.callOnFlip(block2response.clock.reset)  # t=0 on next screen flip
            event.clearEvents(eventType='keyboard')
        if block2response.status == STARTED:
            theseKeys = event.getKeys(keyList=['y', 'n', 'left', 'right', 'space'])
            
            # check for quit:
            if "escape" in theseKeys:
                endExpNow = True
            if len(theseKeys) > 0:  # at least one key was pressed
                block2response.keys = theseKeys[-1]  # just the last key pressed
                block2response.rt = block2response.clock.getTime()
                # a response ends the routine
                continueRoutine = False
        keypresses = event.waitKeys() # returns a list of keypresses 
        
        if len(keypresses) > 0: # at least one key was pushed 
        
            if 'space' in keypresses: 
                
                thisResponseTime = t # the current time in the trial 
                wordNumber = wordNumber + 1 
                if wordNumber < len(sentenceList): 
        
                    if wordNumber == 0: # need to initialise a variable: 
                        timeOfLastResponse = 0 
        
                    # save the inter response interval for this keypress, 
                    # in variables called IRI_0, IRI_1, etc: 
                    thisExp.addData('Region_' + str(wordNumber), thisResponseTime - timeOfLastResponse) 
                    timeOfLastResponse = thisResponseTime 
        
                    # update the text by masking all but the current word 
                    block2sentencetext.text = replaceWithdash(sentenceList, wordNumber) 
                else: 
                    continueRoutine = False # time to go on to the next trial 
        
            elif 'escape' in keypresses: 
        
                core.quit() # I think you'll need to handle quitting manually now. 
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in trialBlock2Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # check for quit (the Esc key)
        if endExpNow or event.getKeys(keyList=["escape"]):
            core.quit()
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "trialBlock2"-------
    for thisComponent in trialBlock2Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # check responses
    if block2response.keys in ['', [], None]:  # No response was made
        block2response.keys=None
    Block2.addData('block2response.keys',block2response.keys)
    if block2response.keys != None:  # we had a response
        Block2.addData('block2response.rt', block2response.rt)
    
    # the Routine "trialBlock2" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "compQuestionsBlock2"-------
    t = 0
    compQuestionsBlock2Clock.reset()  # clock
    frameN = -1
    continueRoutine = True
    # update component parameters for each repeat
    block2_compQuestion.setText(block2compQuestion)
    key_resp_3 = event.BuilderKeyResponse()
    block2compquestionF.setText(block2compQuestionF)
    block2compquestionJ.setText(block2compQuestionJ)
    # keep track of which components have finished
    compQuestionsBlock2Components = [block2_compQuestion, key_resp_3, block2compquestionF, block2compquestionJ]
    for thisComponent in compQuestionsBlock2Components:
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    # -------Start Routine "compQuestionsBlock2"-------
    while continueRoutine:
        # get current time
        t = compQuestionsBlock2Clock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *block2_compQuestion* updates
        if t >= 0.0 and block2_compQuestion.status == NOT_STARTED:
            # keep track of start time/frame for later
            block2_compQuestion.tStart = t
            block2_compQuestion.frameNStart = frameN  # exact frame index
            block2_compQuestion.setAutoDraw(True)
        
        # *key_resp_3* updates
        if t >= 0.0 and key_resp_3.status == NOT_STARTED:
            # keep track of start time/frame for later
            key_resp_3.tStart = t
            key_resp_3.frameNStart = frameN  # exact frame index
            key_resp_3.status = STARTED
            # keyboard checking is just starting
            win.callOnFlip(key_resp_3.clock.reset)  # t=0 on next screen flip
            event.clearEvents(eventType='keyboard')
        if key_resp_3.status == STARTED:
            theseKeys = event.getKeys(keyList=['f', 'j'])
            
            # check for quit:
            if "escape" in theseKeys:
                endExpNow = True
            if len(theseKeys) > 0:  # at least one key was pressed
                key_resp_3.keys = theseKeys[-1]  # just the last key pressed
                key_resp_3.rt = key_resp_3.clock.getTime()
                # was this 'correct'?
                if (key_resp_3.keys == str(block2compQuestionResponse)) or (key_resp_3.keys == block2compQuestionResponse):
                    key_resp_3.corr = 1
                else:
                    key_resp_3.corr = 0
                # a response ends the routine
                continueRoutine = False
        
        # *block2compquestionF* updates
        if t >= 0.0 and block2compquestionF.status == NOT_STARTED:
            # keep track of start time/frame for later
            block2compquestionF.tStart = t
            block2compquestionF.frameNStart = frameN  # exact frame index
            block2compquestionF.setAutoDraw(True)
        
        # *block2compquestionJ* updates
        if t >= 0.0 and block2compquestionJ.status == NOT_STARTED:
            # keep track of start time/frame for later
            block2compquestionJ.tStart = t
            block2compquestionJ.frameNStart = frameN  # exact frame index
            block2compquestionJ.setAutoDraw(True)
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in compQuestionsBlock2Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # check for quit (the Esc key)
        if endExpNow or event.getKeys(keyList=["escape"]):
            core.quit()
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "compQuestionsBlock2"-------
    for thisComponent in compQuestionsBlock2Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # check responses
    if key_resp_3.keys in ['', [], None]:  # No response was made
        key_resp_3.keys=None
        # was no response the correct answer?!
        if str(block2compQuestionResponse).lower() == 'none':
           key_resp_3.corr = 1  # correct non-response
        else:
           key_resp_3.corr = 0  # failed to respond (incorrectly)
    # store data for Block2 (TrialHandler)
    Block2.addData('key_resp_3.keys',key_resp_3.keys)
    Block2.addData('key_resp_3.corr', key_resp_3.corr)
    if key_resp_3.keys != None:  # we had a response
        Block2.addData('key_resp_3.rt', key_resp_3.rt)
    # the Routine "compQuestionsBlock2" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    thisExp.nextEntry()
    
# completed 1 repeats of 'Block2'


# ------Prepare to start Routine "Thanks"-------
t = 0
ThanksClock.reset()  # clock
frameN = -1
continueRoutine = True
routineTimer.add(4.000000)
# update component parameters for each repeat
# keep track of which components have finished
ThanksComponents = [text_3]
for thisComponent in ThanksComponents:
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

# -------Start Routine "Thanks"-------
while continueRoutine and routineTimer.getTime() > 0:
    # get current time
    t = ThanksClock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *text_3* updates
    if t >= 0.0 and text_3.status == NOT_STARTED:
        # keep track of start time/frame for later
        text_3.tStart = t
        text_3.frameNStart = frameN  # exact frame index
        text_3.setAutoDraw(True)
    frameRemains = 0.0 + 4.0- win.monitorFramePeriod * 0.75  # most of one frame period left
    if text_3.status == STARTED and t >= frameRemains:
        text_3.setAutoDraw(False)
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in ThanksComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # check for quit (the Esc key)
    if endExpNow or event.getKeys(keyList=["escape"]):
        core.quit()
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Thanks"-------
for thisComponent in ThanksComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)


# these shouldn't be strictly necessary (should auto-save)
thisExp.saveAsWideText(filename+'.csv')
thisExp.saveAsPickle(filename)
logging.flush()
# make sure everything is closed down
thisExp.abort()  # or data files will save again on exit
win.close()
core.quit()
